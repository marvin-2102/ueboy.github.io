package rita.wordnet.jwnl.dictionary;

import rita.wordnet.jwnl.JWNLRuntimeException;

public class JWNLPosException extends JWNLRuntimeException
{

  public JWNLPosException(String key)
  {
    super(key);
  }

}

package rita.support;


public interface StemmerIF
{
  public String stem(String s);
}